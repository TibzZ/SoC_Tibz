﻿using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Threading.Tasks;


[ApiController]
[Route("books")]
public class BookController : ControllerBase
{
    private readonly IRepository<Book> _bookRepository;

    public BookController(IRepository<Book> bookRepository)
    {
        _bookRepository = bookRepository;
    }

    [HttpGet]
    //lets make this async
    public async Task<IActionResult> GetAll()
    {
        try
        {
            var allBooks = await _bookRepository.GetAll();
            return Ok(allBooks);
        }
        catch (Exception)
        {
            return NotFound($"There is nothing that can be returned");
        }
    }


    [HttpGet("{id}")]
    //change IEnumberable<Book> to IActionResult
    public async Task<IActionResult> Get(long id)
    {
        //add in a try catch code block
        try
        {
            //this is the code we are testing
            var bookId = await _bookRepository.Get(id);
            //this returns the book at the ID
            return Ok(bookId);
        }
        catch (Exception)      // Accept acception we can catch it
        {
            //this returns  status code 404 if the book ID does not exist
            //and some wording in the body.
            return NotFound($"no book with id {id}");
        }

    }

    [HttpDelete("{id}")]
    public void Delete(long id)
    {
        _bookRepository.Delete(id);
    }

    [HttpPut("{id}")]
    public async Task<IActionResult> Update(long id, [FromBody] Book book)
    {
        try
        {
        // if we don't want to be null but have it then ... have throw error 
            var myUpdate = await _bookRepository.Update(new Book { Id = id, Title = book.Title, Author = book.Author });
            return Ok(myUpdate);
        
        }
        catch (Exception)
        {
            return NotFound($"Your entry {id} could not be updated as it doesn't include all elements for an update");
        }
    }

    [HttpPost]
    public Book Insert([FromBody] Book book)
    {
        return _bookRepository.Insert(book);
    }
}

