using System.Collections.Generic;
using System.Threading.Tasks; // changed to allow async function

public interface IRepository<T>
{
    Task<IEnumerable<T>> GetAll();
    void Delete(long id);
    Task<T> Get(long id);             // T for GET changed for Task < >
    Task<T> Update(T t);
    T Insert(T t);
}