# ASP(arations).NET

By completing the tasks in this repo, you will end up with a good example of an ASP.NET application. The only thing we'll leave as a to do at this stage is Authentication and Authorization, and Unit Tests.

## Making Our App Configurable

If you look in `BookApi/BaseRepository.cs`, you will see that we are taking in configuration in the constructor using IConfiguration. This is injected into `BookApi/BookRepository.cs` using dependency injection and handed through to the base constructor.

This configuration object is given to us for free by the ASP.NET dependency injection container and is how we should get access to environment variables.

Now we know that we should **NEVER COMMIT ENV VARS TO GIT**, we will always be getting our variables from the environment. IConfiguration can get hold of the variables from a[variety of places](https://docs.microsoft.com/en-us/aspnet/core/fundamentals/configuration/?view=aspnetcore-5.0), we will be using [dotnet secrets manager](https://docs.microsoft.com/en-us/aspnet/core/security/app-secrets?view=aspnetcore-5.0&tabs=linux#enable-secret-storage).

👉 Use the dotnet secrets manager to store the variable required to connect to postgres (PGHOST, PGDATABASE, PGUSER, PGPORT, PGPASSWORD).

## Returning IActionResult from Controller Methods

Returning an action result allows us greater control and flexibility. Control to return the correct HTTP response codes with our data, and flexibility to return different formations of data.

👉 Convert your controller base methods to return IActionResult using the helper methods from the [ControllerBase](https://docs.microsoft.com/en-us/dotnet/api/microsoft.aspnetcore.mvc.controllerbase?view=aspnetcore-5.0)
e.g.

- Ok(_myResponseData_) will return 200
- NotFound() will return 404

## Error Handling

Applications should not break if they receive a bad request, they should just tell us off! Now that we are returning IActionResult from our controller methods we have the freedom to return informative responses when our client strays from "the golden path".

👉 Use try/catch in your controller so that when errors are thrown, you catch them and return the appropriate action result.

## Async/Await

So far we have been doing everything synchronously. Lets fix that to make the most of the resources at our applications disposal and increase potential throughput.

👉 Make every method async and return a Task

👉 Await any method that is now async

👉 Remember to convert the Dapper methods too!

## Query Params

Add the ability to search for an item by name using a [query string](https://softwareengineering.stackexchange.com/questions/270898/designing-a-rest-api-by-uri-vs-query-string)

When a request to `/books?search=mybook` is made, we should return all the books where the title or the author includes "mybook".

ToDo...

- Add a Search Method to the interface that will take in a string and return a list of books
- Implement the Search method in `BooksRepository`
- Refactor the GetAll method in your controller to take a query of search
  - If you receive a search query, return the result of your new repository.Search method
  - else return repository.GetAll
# w5d4ReviewFullAPI
